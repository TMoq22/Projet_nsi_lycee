# Projet NSI : Site Web avec Flask et Base de Données

## Introduction

Ce projet a pour but de créer un site web interactif en utilisant le framework Flask et une base de données pour stocker et récupérer des informations. Le site permettra aux utilisateurs de consulter, ajouter, modifier et supprimer des données via une interface web.

## Prérequis

- Python 3.x
- Flask 
- SQLite

## Utilisation

1. Lancez le programme Python:

2. Ouvrez votre navigateur et accédez à `http://127.0.0.1:5558/` pour voir le site web en action.

## Développement 
Ce projet est toujours en développement ,de nombreuses "fonctionnalités ne sont donc pas encore disponibles
Le code n'est pas encore très bien organisé et nécessite encore de nombreuses modifications
Des mises à jour serons postées des que possibles 
